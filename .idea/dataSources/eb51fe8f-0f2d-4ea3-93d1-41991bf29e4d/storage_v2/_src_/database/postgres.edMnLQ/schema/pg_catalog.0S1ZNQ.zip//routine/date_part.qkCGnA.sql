CREATE FUNCTION date_part(text, reltime)
  RETURNS double precision
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$;

